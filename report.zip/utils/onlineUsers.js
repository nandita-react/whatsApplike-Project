const onlineUsers = new Map();
module.exports = onlineUsers;