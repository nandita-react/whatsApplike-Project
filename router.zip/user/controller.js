const Repository = require('./repository');
const generateToken = require('../utils/generateToken');
const handler = require('../handler');


exports.registerUser = async (req, res) => {
    const userRepo = new Repository(req);

    try {
        const existuser = await userRepo.findbyPhone(req.body.phoneNumber);
        if (existuser) {
            return handler.errorResponse(res, new Error('User already exist'));
        }
        if (req.file) {
            req.body.image = {
                url: `/upload/${req.file.filename}`
            }
        }
        const user = await userRepo.create();
        const token = generateToken(user);
        return handler.createdResponse(res, { user, token }, "User Create Successfully")
    }
    catch (error) {
        return handler.errorResponse(res,error)
    }
};

exports.getProfile = async (req, res) => {
    const userRepo = new Repository(req);

    try {
        const user = await userRepo.findById(req.params.id);
        return handler.successResponse(res, user, "Profile fetch successful");
    }
    catch (error) {
        return handler.errorResponse(res, error);
    }
}

exports.logInUser = async (req, res) => {
    const userRepo = new Repository(req);

    try {
        const user = await userRepo.findbyPhone(req.body.phoneNumber);
        if (!user) return handler.errorResponse(new Error('User not found'), 404);
        const token = generateToken(user);
        return handler.successResponse(res, { user, token }, "login successfully")
    }
    catch (error) {
        return handler.errorResponse(res, error);
    }
}
