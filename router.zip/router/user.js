const express=require('express');

const routes=express.Router();

const userController=require("../user/controller");
const upload=require("../middleware/upload")

routes.post("/create",upload.single('image'),userController.registerUser);
routes.patch("/login",userController.logInUser);
routes.get("/profile",userController.getProfile);



module.exports=routes